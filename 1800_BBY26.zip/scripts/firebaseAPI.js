var firebaseConfig = {
  apiKey: "AIzaSyAIuQkV7cgkjwhKHC06nLcKQICtfLhh9_o",
  authDomain: "comp1800-bby26.firebaseapp.com",
  projectId: "comp1800-bby26",
  storageBucket: "comp1800-bby26.appspot.com",
  messagingSenderId: "626264143236",
  appId: "1:626264143236:web:ad885148d65675e988d9d1"
};


// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const storage = firebase.storage();